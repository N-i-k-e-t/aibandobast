
# PS Playbook — Mumbai Naka

**Zone:** Zone 1  |  **Festival Window:** 2025‑08‑27 → 2025‑09‑07 (IST)

## A. Procession Routes
List mandals and routes within Mumbai Naka; specify starting points, via roads, and ghats. (TO‑VERIFY)

## B. Diversions & Closures
List diversion IDs, locations, from→to, alt routes, signage, cones, and steward assignments. (TO‑VERIFY)

## C. Posts & Staging
Specify posts with location descriptions, shifts, start/end times, headcounts (HC), constables (PC), home guards (HG), SRPF, reserve%, incharge, and radio call. (TO‑VERIFY)

## D. Sensitive Points
Identify sensitive spots (temples, markets, communities) and note risk factors. (TO‑VERIFY)

## E. Emergency Reroutes
Define trigger‑based reroutes (e.g., V1–V5 alerts), detailing alternative paths and communication steps. (TO‑VERIFY)

## F. Volunteer & NGO Coordination
List mandal volunteers, NGOs, and contact persons for coordination. (TO‑VERIFY)

## DONE_WHEN
- Routes/diversions listed and verified.
- Posts assigned with roles and shifts.
- Sensitive points assessed and mitigations planned.
- All TO‑VERIFY items assigned owners and deadlines.
