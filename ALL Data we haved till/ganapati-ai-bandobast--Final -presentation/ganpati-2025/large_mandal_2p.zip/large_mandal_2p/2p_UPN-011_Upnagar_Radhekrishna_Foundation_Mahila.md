# Mandal Two‑Pager — Radhekrishna Foundation (Mahila Mandal) (UPN-011)

**ID:** UPN-011  |  **PS:** Upnagar  |  **Zone:** Zone 2

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 19.95251
- Longitude: 73.82507

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
