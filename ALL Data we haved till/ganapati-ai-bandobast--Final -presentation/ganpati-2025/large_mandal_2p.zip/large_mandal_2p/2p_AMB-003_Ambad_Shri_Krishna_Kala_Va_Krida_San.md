# Mandal Two‑Pager — Shri Krishna Kala Va Krida Sanskrutik Mitra Mandal (Valuable) (AMB-003)

**ID:** AMB-003  |  **PS:** Ambad  |  **Zone:** Zone 2

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 19.96777777
- Longitude: 73.74099999

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
