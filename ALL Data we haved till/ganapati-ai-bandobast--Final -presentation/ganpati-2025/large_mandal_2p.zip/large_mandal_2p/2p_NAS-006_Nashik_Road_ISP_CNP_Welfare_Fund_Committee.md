# Mandal Two‑Pager — ISP / CNP Welfare Fund Committee Ganeshotsav 2024 (NAS-006)

**ID:** NAS-006  |  **PS:** Nashik Road  |  **Zone:** Zone 2

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 19.952709
- Longitude: 73.840278

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
