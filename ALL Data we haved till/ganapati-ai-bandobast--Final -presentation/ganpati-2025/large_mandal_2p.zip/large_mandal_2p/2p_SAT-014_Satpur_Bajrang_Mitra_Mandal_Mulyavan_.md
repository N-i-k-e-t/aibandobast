# Mandal Two‑Pager — Bajrang Mitra Mandal (Mulyavan Ganpati) (SAT-014)

**ID:** SAT-014  |  **PS:** Satpur  |  **Zone:** Zone 2

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 19.978786
- Longitude: 73.727007

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
