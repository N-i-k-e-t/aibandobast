# Mandal Two‑Pager — Kamgar Nagar Mitra Mandal (Kamgar Nagarcha Raja) (SAT-015)

**ID:** SAT-015  |  **PS:** Satpur  |  **Zone:** Zone 2

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 20.002849
- Longitude: 73.74681

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
