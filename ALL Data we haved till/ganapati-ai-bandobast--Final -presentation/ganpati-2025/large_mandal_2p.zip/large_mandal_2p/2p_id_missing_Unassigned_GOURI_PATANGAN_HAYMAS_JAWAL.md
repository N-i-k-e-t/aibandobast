# Mandal Two‑Pager — GOURI PATANGAN HAYMAS JAWAL

**ID:** unknown  |  **PS:** Unassigned  |  **Zone:** 

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 20.003108
- Longitude: 73.794137

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
