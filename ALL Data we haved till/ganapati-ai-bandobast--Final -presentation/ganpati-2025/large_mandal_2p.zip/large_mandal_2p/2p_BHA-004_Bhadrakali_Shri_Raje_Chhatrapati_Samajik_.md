# Mandal Two‑Pager — Shri. Raje Chhatrapati Samajik Sanskrutik Kala Va Krida Mitra Mandal (BHA-004)

**ID:** BHA-004  |  **PS:** Bhadrakali  |  **Zone:** Zone 1

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 19.9993
- Longitude: 73.78483

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
