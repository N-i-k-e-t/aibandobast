# Mandal Two‑Pager — Bhoiraj Foundation (BHA-038)

**ID:** BHA-038  |  **PS:** Bhadrakali  |  **Zone:** Zone 1

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 19.99716
- Longitude: 73.79546

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
