# Mandal Two‑Pager — Nayshiv Bajrang Arts, Sports and Cultural Charitable Institution (PAN-005)

**ID:** PAN-005  |  **PS:** Panchavati  |  **Zone:** Zone 1

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 20.01796
- Longitude: 73.793827

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
