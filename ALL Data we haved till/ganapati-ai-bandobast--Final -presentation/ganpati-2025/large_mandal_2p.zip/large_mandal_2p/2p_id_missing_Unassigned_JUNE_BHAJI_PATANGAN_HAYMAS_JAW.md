# Mandal Two‑Pager — JUNE BHAJI PATANGAN HAYMAS JAWAL

**ID:** unknown  |  **PS:** Unassigned  |  **Zone:** 

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 20.006712
- Longitude: 73.792728

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
