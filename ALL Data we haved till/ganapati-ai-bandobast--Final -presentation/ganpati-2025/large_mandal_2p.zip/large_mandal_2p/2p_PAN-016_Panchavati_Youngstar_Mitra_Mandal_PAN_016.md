# Mandal Two‑Pager — Youngstar Mitra Mandal (PAN-016)

**ID:** PAN-016  |  **PS:** Panchavati  |  **Zone:** Zone 1

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 20.007351
- Longitude: 73.791726

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
