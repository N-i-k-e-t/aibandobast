# Mandal Two‑Pager — Bajrang Mitra Mandal (Vadar Yuva Pratishthan) (SAT-002)

**ID:** SAT-002  |  **PS:** Satpur  |  **Zone:** Zone 2

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 19.991048
- Longitude: 73.733558

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
