# Mandal Two‑Pager — Roshan Bhau Ghate Charitable Trust Pranit Sahyadri Yuva Pratishthan (GAN-008)

**ID:** GAN-008  |  **PS:** Gangapur  |  **Zone:** Zone 1

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 20.008743
- Longitude: 73.755379

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
