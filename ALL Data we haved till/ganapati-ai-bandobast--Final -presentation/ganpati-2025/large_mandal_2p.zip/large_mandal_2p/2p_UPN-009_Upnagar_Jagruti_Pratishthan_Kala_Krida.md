# Mandal Two‑Pager — Jagruti Pratishthan Kala & Krida Sanskrutik Mitra Mandal (UPN-009)

**ID:** UPN-009  |  **PS:** Upnagar  |  **Zone:** Zone 2

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 19.97643
- Longitude: 73.80576

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
