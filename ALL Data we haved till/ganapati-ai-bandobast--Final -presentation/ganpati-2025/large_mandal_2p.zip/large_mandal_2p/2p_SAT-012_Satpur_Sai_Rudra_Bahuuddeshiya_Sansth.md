# Mandal Two‑Pager — Sai Rudra Bahuuddeshiya Sanstha (SAT-012)

**ID:** SAT-012  |  **PS:** Satpur  |  **Zone:** Zone 2

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 19.986839
- Longitude: 73.715498

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
