# Mandal Two‑Pager — Late Dharmaraj Barode Bahu-Uddeshiya Sanstha Pranit Shripratishthan, Indiranagar (IND-003)

**ID:** IND-003  |  **PS:** Indiranagar  |  **Zone:** Zone 2

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 19.96497
- Longitude: 73.779961

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
