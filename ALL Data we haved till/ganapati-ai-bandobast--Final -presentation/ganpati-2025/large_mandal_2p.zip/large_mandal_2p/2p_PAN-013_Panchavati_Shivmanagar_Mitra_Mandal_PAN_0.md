# Mandal Two‑Pager — Shivmanagar Mitra Mandal (PAN-013)

**ID:** PAN-013  |  **PS:** Panchavati  |  **Zone:** Zone 1

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 20.012674
- Longitude: 73.805732

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
