# Mandal Two‑Pager — Sheshrao Maharaj Mitra Mandal (PAN-007)

**ID:** PAN-007  |  **PS:** Panchavati  |  **Zone:** Zone 1

## Profile
- Type: general
- Crowd Band: unknown
- Risk Flags: unknown
- Latitude: 20.02116
- Longitude: 73.795267

## Route & Immersion
- Procession Route: TO‑VERIFY
- Immersion Point: TO‑VERIFY
- Day: TO‑VERIFY

## Safety & Resources
- Minimum Stewards: TO‑VERIFY
- Volunteers: TO‑VERIFY
- Police Deployment: TO‑VERIFY

## Notes
- TO‑VERIFY

---
